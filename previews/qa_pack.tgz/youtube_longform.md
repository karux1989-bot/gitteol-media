# 유튜브 롱폼 — 깃털 루트 오사카 하루 (검수 전 초안)

## 제목 후보
1. 오사카 하루 동선 총정리 | 공항→오사카성→구로몬→쓰텐카쿠→도톤보리 (2026 최신 요금)
2. 오사카 처음이면 이 순서로 | 하루 예산 4,370엔부터, 주유패스 계산까지
3. 오사카 딱 하루, 어디부터 갈까? 공식 요금으로 짠 하루 루트

## 설명란
오사카에 딱 하루. 공항에서 출발해 오사카성, 구로몬시장, 신세카이·쓰텐카쿠를 지나 밤의 도톤보리까지, 처음 가는 사람을 위한 하루 길을 정리했습니다.
요금·시간은 각 공식 안내 기준(2026년 11월 확인)입니다. 출발 전에 한 번 더 확인해 주세요.

⏱ 챕터
00:00 시작
00:18 오사카는 어떤 곳
00:35 간사이공항 → 난바 (난카이 전철·라피트)
01:10 오사카 주유패스
01:43 하루 동선 한눈에
01:59 오사카성 천수각
02:51 구로몬시장
03:18 신세카이·쓰텐카쿠
03:54 도톤보리·돈보리 리버 크루즈
04:30 하루 예산 (패스 있을 때·없을 때)
04:54 떠나기 전 체크리스트

📌 하루 예산 (교통 + 입장)
라피트 1,670엔(차표 970엔 + 특급요금 700엔) · 오사카성 1,200엔 · 쓰텐카쿠 1,500엔 = 4,370엔 (+ 지하철·식비 별도)
주유패스 1일권 3,500엔 — 지하철·버스 + 오사카성·쓰텐카쿠·리버 크루즈 포함 (라피트는 별도)
※ 난카이 차표 970엔은 운임 검색 기준 금액입니다. 공식 운임표로 한 번 더 확인해 주세요.

🔗 공식 안내 (2026-11-06 확인)
· 난카이 전철 특급요금 개정: https://www.nankai.co.jp/lib/company/news/pdf/260122.pdf
· 오사카 주유패스: https://osaka-amazing-pass.com/kr/
· 오사카성 천수각: https://www.osakacastle.net/
· 오사카시 발표(천수각 입관자): https://www.city.osaka.lg.jp/hodoshiryo/keizaisenryaku/0000676926.html
· 오사카관광국 쓰텐카쿠: https://osaka-info.jp/spot/tsutenkaku/
· 오사카관광국 구로몬시장: https://osaka-info.jp/en/spot/kuromon-market
· 오사카관광국 에비스바시: https://osaka-info.jp/experience/ja/osaka/spot/551

🎬 사용한 영상·사진
· 지도: © OpenStreetMap contributors (openstreetmap.org/copyright)
· 영상: Pixabay, Pexels / 사진: Pixabay, Unsplash
· Wikimedia Commons 사진
  - "Nankai 50000 series Rapit at Namba Station 2017-03-12" — 蘇育群, CC BY-SA 2.0, https://commons.wikimedia.org/wiki/File:Nankai_50000_series_Rapit_at_Namba_Station_2017-03-12.jpg
  - "Nankai 50000 series 50002F" — 日根野, CC BY-SA 4.0, https://commons.wikimedia.org/wiki/File:Nankai_50000_series_50002F.jpg
  - "Nankai-Dentetsu-Rapi-t-int" — Electroliner, Public domain, https://commons.wikimedia.org/wiki/File:Nankai-Dentetsu-Rapi-t-int.JPG
  - "Nankai namba station01s2560" — 663highland, CC BY 2.5, https://commons.wikimedia.org/wiki/File:Nankai_namba_station01s2560.jpg
· 내레이션: AI 음성 / 배경음악: AI로 만든 곡

#오사카여행 #오사카 #오사카하루코스 #일본여행 #오사카주유패스 #도톤보리 #오사카성 #깃털루트

## 태그
오사카여행, 오사카, 오사카 하루 코스, 오사카 동선, 일본여행, 오사카 주유패스, 라피트, 간사이공항, 오사카성, 구로몬시장, 쓰텐카쿠, 신세카이, 도톤보리, 돈보리 리버 크루즈, 오사카 경비

## 업로드 설정 메모
- "변경되거나 합성된 콘텐츠" 표시: 실제 사람·장소를 사실처럼 보이게 바꾼 장면은 없음. 다만 기획서(trip-longform-plan-03)대로 AI 음성 사용을 설명란에 밝힘
- 자막: osaka_lf_test.srt 를 한국어 자막으로 업로드 (화면에 새긴 자막과 같은 내용)
- 언어: 한국어 · 카테고리: 여행/이벤트
- 같은 도시 숏폼(EP.01 오사카)에 관련 동영상으로 이 롱폼 연결
